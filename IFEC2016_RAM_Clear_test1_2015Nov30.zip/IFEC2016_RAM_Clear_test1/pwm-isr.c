/*
 * pwm-isr.c
 *
 *  Created on: Nov 30, 2015
 *      Author: Steffon Brigman
 */
#include "DSP28x_Project.h"
#include "macros.h"
#include "strings.h"
#include "functions.h"

// Functions that will be run from RAM need to be assigned to
// a different section.  This section will then be mapped using
// the linker cmd file.
//Uint32  EPwm5TimerIntCount;
#pragma CODE_SECTION(epwm5_timer_isr, "ramfuncs");
interrupt void epwm5_timer_isr(void)
{
	EPwm5TimerIntCount++;
	EPwm5Regs.CMPA.half.CMPA = 200;
	EPwm5Regs.CMPB = 100;

	// Clear INT flag for this timer
	EPwm5Regs.ETCLR.bit.INT = 1;

	// Acknowledge this interrupt to receive more interrupts from group 3
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}
