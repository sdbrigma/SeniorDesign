//Add Watch window Variables
expRemoveAll
expAdd "EPwm1TimerIntCount" getNatural()
expAdd "EPwm2TimerIntCount" getNatural()
expAdd "EPwm3TimerIntCount" getNatural()
